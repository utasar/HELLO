import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Create JFrame
        JFrame frame = new JFrame("Component List Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Create root JPanel
        JPanel rootPanel = new JPanel();

        // Create ComponentList object (empty for now)
        ComponentList<JButton> btnList = new ComponentList<>();

        // Add ComponentList to root panel
        rootPanel.add(btnList);

        // Add root panel to frame and display
        frame.add(rootPanel);
        frame.setVisible(true);
    }
}
