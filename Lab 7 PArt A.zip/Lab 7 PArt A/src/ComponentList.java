import javax.swing.*;
import java.util.ArrayList;

public class ComponentList<T extends JComponent> extends JPanel {
    // Inner list to store components
    private ArrayList<T> componentList;

    // No-argument constructor
    public ComponentList() {
        componentList = new ArrayList<>();
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); // Stack components vertically
    }

    // Method to add a component to the list
    public void addComponent(T component) {
        componentList.add(component);
        add(component); // Add component to JPanel
    }

    // Method to get component at a specific index
    public T getComponentAtIndex(int index) {
        return componentList.get(index);
    }
}
