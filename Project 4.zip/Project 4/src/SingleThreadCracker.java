import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

/**
 * Utsav Acharya
 * CS 1181 - Project 4 - Part 1
 * Cracks a 3-letter lowercase password from protected3.zip using brute-force recursion.
 */
public class SingleThreadCracker {
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    private static final int PASSWORD_LENGTH = 3;
    private static boolean passwordFound = false;

    public static void main(String[] args) {
        long start = System.currentTimeMillis();
        crack("", 0, "protected3.zip", "super_secret_output.txt");
        long end = System.currentTimeMillis();
        System.out.println("Time taken: " + (end - start) + " ms");
    }

    private static void crack(String current, int depth, String zipFile, String outputPath) {
        if (passwordFound) return;

        if (depth == PASSWORD_LENGTH) {
            if (tryPassword(zipFile, current, outputPath)) {
                System.out.println("✅ Password: " + current);
                passwordFound = true;
            }
            return;
        }

        for (char c : ALPHABET.toCharArray()) {
            crack(current + c, depth + 1, zipFile, outputPath);
        }
    }

    private static boolean tryPassword(String zipPath, String password, String outputPath) {
        try {
            ZipFile zip = new ZipFile(zipPath);
            zip.setPassword(password.toCharArray());
            zip.extractAll(outputPath);
            return true;
        } catch (ZipException e) {
            return false;
        }
    }
}
