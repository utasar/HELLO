import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Utsav Acharya
 * CS 1181 - Project 4 - Part 2
 * Multithreaded brute-force cracker for protected5.zip
 * Password: lowercase, exactly 5 letters.
 */
public class MultiThreadCracker {
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    private static final int PASSWORD_LENGTH = 5;
    private static final int numThreads = 4;
    private static volatile boolean passwordFound = false;

    public static void main(String[] args) {
        long start = System.currentTimeMillis();

        Thread[] threads = new Thread[numThreads];
        for (int i = 0; i < numThreads; i++) {
            int threadID = i;
            threads[i] = new Thread(() -> runThread(threadID));
            threads[i].start();
        }

        for (Thread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        long end = System.currentTimeMillis();
        System.out.println("Time taken: " + (end - start) + " ms");
    }

    private static void runThread(int id) {
        long threadStart = System.currentTimeMillis();
        int range = ALPHABET.length() / numThreads;
        int startIdx = id * range;
        int endIdx = (id == numThreads - 1) ? ALPHABET.length() : startIdx + range;

        String zipCopy = "thread_" + id + ".zip";
        String extractPath = "out-" + id;

        try {
            Files.copy(Path.of("protected5.zip"), Path.of(zipCopy));
            for (int i = startIdx; i < endIdx && !passwordFound; i++) {
                char firstChar = ALPHABET.charAt(i);
                recurse(zipCopy, extractPath, new char[PASSWORD_LENGTH], 0, firstChar);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                Files.deleteIfExists(Path.of(zipCopy));
                deleteDir(new File(extractPath));
            } catch (IOException e) {
                e.printStackTrace();
            }
            long threadEnd = System.currentTimeMillis();
            System.out.println("Thread " + id + " ran for " + (threadEnd - threadStart) + " ms");
        }
    }

    private static void recurse(String zip, String extractPath, char[] pass, int idx, char first) {
        if (passwordFound) return;
        if (idx == 0) {
            pass[idx] = first;
            recurse(zip, extractPath, pass, idx + 1, first);
            return;
        }
        if (idx == PASSWORD_LENGTH) {
            String guess = new String(pass);
            if (tryPassword(zip, extractPath, guess)) {
                System.out.println("✅ Password found: " + guess);
                passwordFound = true;
            }
            return;
        }

        for (char c : ALPHABET.toCharArray()) {
            if (passwordFound) break;
            pass[idx] = c;
            recurse(zip, extractPath, pass, idx + 1, first);
        }
    }

    private static boolean tryPassword(String zipPath, String output, String guess) {
        try {
            ZipFile zipFile = new ZipFile(zipPath);
            zipFile.setPassword(guess.toCharArray());
            zipFile.extractAll(output);
            return true;
        } catch (ZipException e) {
            return false;
        }
    }

    private static void deleteDir(File dir) throws IOException {
        if (dir.isDirectory()) {
            for (File file : dir.listFiles()) {
                deleteDir(file);
            }
        }
        Files.deleteIfExists(dir.toPath());
    }
}
