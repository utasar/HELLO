//Utsav Acharya
//CLarissa
// Project 3
//Dhruv brother help me in truck and drone time
//Google was used i just forgot what i was for (stack over flow , oracle,jetbrain and gpt was for java doc )
//public class Main {
//    public static void main(String[] args) {
//        PackageDelivery.runSimulation(); // Starts the simulation
//    }
//}
/**
 * The main class that initiates the package delivery simulation.
 * It calls the runSimulation method from the PackageDelivery class.
 *
 * @author Utsav Acharya
 * @version 1.0
 * @since 2025-04-06
 */
public class Main {
    public static void main(String[] args) {
        PackageDelivery.runSimulation(); // Starts the simulation
    }
}
